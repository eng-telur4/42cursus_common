#ifndef LIBFTPRINT_H
# define LIBFTPRINT_H

int ft_printf(const char *, ...);

#endif
