## gnl station 2022

clone in your gnl repo then "make"

```
git clone https://github.com/kodpe/42test-gnl-station-2022.git
```

- Ubuntu (with leaks check)
- do not test the bonus part

![alt text](https://i.imgur.com/JLAlL16.png)


